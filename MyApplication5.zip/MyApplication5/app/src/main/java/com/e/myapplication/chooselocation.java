package com.e.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

public class chooselocation extends AppCompatActivity {
    RelativeLayout Relative2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chooselocation);

        Relative2=(RelativeLayout) findViewById(R.id.Relative2);
        Relative2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(chooselocation.this, Bookmap.class);
                startActivity(intent);
            }
        });
    }
}