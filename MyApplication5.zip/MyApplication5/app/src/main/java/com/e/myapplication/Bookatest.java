package com.e.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

public class Bookatest extends AppCompatActivity {

    LinearLayout Linear;
    LinearLayout Linear1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookatest);

        Linear=(LinearLayout)findViewById(R.id.Linear);
        Linear1=(LinearLayout)findViewById(R.id.Linear1);
        Linear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Bookatest.this, chooselocation.class);
                startActivity(intent);
            }
        });

        Linear1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Bookatest.this, booktimesloat.class);
                startActivity(intent);
            }
        });
    }
}